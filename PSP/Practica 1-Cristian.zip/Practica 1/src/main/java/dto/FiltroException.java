package dto;

public class FiltroException extends Exception {

    public FiltroException(String message) {
        super(message);
    }
}
