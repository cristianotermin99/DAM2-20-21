INSERT INTO practica1.espia (nombreEspia, raza) VALUES ('Juan', 'Elfo');
INSERT INTO practica1.espia (nombreEspia, raza) VALUES ('Monica', 'Humana');
INSERT INTO practica1.espia (nombreEspia, raza) VALUES ('Silvia', 'Orco');