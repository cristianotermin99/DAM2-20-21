INSERT INTO practica1.faccionesrealizanbatalla (nombreFaccion, nombreBatalla) VALUES ('Seton', 'Esternocle');
INSERT INTO practica1.faccionesrealizanbatalla (nombreFaccion, nombreBatalla) VALUES ('Tsuneo', 'Esternocle');
INSERT INTO practica1.faccionesrealizanbatalla (nombreFaccion, nombreBatalla) VALUES ('Tsuneo', 'Mastodonte');
INSERT INTO practica1.faccionesrealizanbatalla (nombreFaccion, nombreBatalla) VALUES ('Xore', 'Mastodonte');