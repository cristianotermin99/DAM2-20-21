INSERT INTO practica1.batalla (nombreBatalla, fechaBatalla, nombreEspia) VALUES ('Alcada', '2020-10-17', 'Juan');
INSERT INTO practica1.batalla (nombreBatalla, fechaBatalla, nombreEspia) VALUES ('Estera', '2020-10-27', 'Silvia');
INSERT INTO practica1.batalla (nombreBatalla, fechaBatalla, nombreEspia) VALUES ('Percula', '2020-10-01', 'Monica');