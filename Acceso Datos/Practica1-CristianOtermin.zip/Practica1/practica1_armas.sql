INSERT INTO practica1.armas (idArma, precio, nombreArma, nombreFaccion) VALUES ('01', 102, 'ak47', 'Tsuneo');
INSERT INTO practica1.armas (idArma, precio, nombreArma, nombreFaccion) VALUES ('02', 451, 'M4', 'Seton');
INSERT INTO practica1.armas (idArma, precio, nombreArma, nombreFaccion) VALUES ('03', 106, 'Bazooka', 'Xore');